#!/bin/bash
INF=1

while [ 0 -lt 1 ] 
do  
	INF=1
done
exit
